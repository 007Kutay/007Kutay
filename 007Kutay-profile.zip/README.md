<p align="center">
  <img src="./assets/banner.svg" alt="Kutay — Computer Engineering Student · Full-Stack · Mobile · AI Automation" width="100%" />
</p>

<p align="center">
  <a href="https://www.linkedin.com/in/YOUR-LINKEDIN/"><img src="https://img.shields.io/badge/LinkedIn-0A66C2?style=flat-square&logo=linkedin&logoColor=white" alt="LinkedIn" /></a>
  <a href="mailto:YOUR-EMAIL"><img src="https://img.shields.io/badge/Email-D14836?style=flat-square&logo=gmail&logoColor=white" alt="Email" /></a>
  <img src="https://img.shields.io/badge/Open_to-Internships_%26_Junior_Roles-7ee0c3?style=flat-square" alt="Open to internships" />
</p>

---

### 👨‍💻 About Me

I'm a Computer Engineering student who enjoys the full journey of a product — from designing the database schema to shipping the interface a user actually touches. My focus is on **full-stack web architectures** and **mobile development**, with a growing interest in **AI-powered automation**.

Before writing code full-time, I worked as a **sales advisor**. That experience taught me something many developers learn late: software exists to solve real people's problems. I bring that user-first mindset, clear communication, and team discipline into every project I build.

```js
const kutay = {
  role: "Computer Engineering Student",
  focus: ["Full-Stack Web", "Mobile Development", "AI Automation"],
  backend: ["Node.js", "Python", "REST APIs"],
  database: ["PostgreSQL"],
  strengths: ["Problem solving", "User-focused thinking", "Teamwork"],
  currentlyLearning: "System design & scalable architectures",
};
```

---

### 🛠️ Tech Stack

<p>
  <img src="https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black" alt="JavaScript" />
  <img src="https://img.shields.io/badge/Python-3776AB?style=for-the-badge&logo=python&logoColor=white" alt="Python" />
  <img src="https://img.shields.io/badge/Node.js-339933?style=for-the-badge&logo=nodedotjs&logoColor=white" alt="Node.js" />
  <img src="https://img.shields.io/badge/Express-000000?style=for-the-badge&logo=express&logoColor=white" alt="Express" />
  <img src="https://img.shields.io/badge/PostgreSQL-4169E1?style=for-the-badge&logo=postgresql&logoColor=white" alt="PostgreSQL" />
  <img src="https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white" alt="HTML5" />
  <img src="https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white" alt="CSS3" />
  <img src="https://img.shields.io/badge/Git-F05032?style=for-the-badge&logo=git&logoColor=white" alt="Git" />
</p>

---

### 🚀 Featured Projects

| Project | Description | Stack |
|---|---|---|
| **[Flux-door](https://github.com/007Kutay/Flux-door)** | End-to-end web platform with AI-driven automation workflows. | Node.js · PostgreSQL · JavaScript |
| **Image-Based Product Recognition** | Simulation that identifies products from images to automate cataloging and inventory flows. | Python · Computer Vision |
| **REST API Services** | Modular, documented APIs with clean database design and authentication. | Node.js · Express · PostgreSQL |

---

### 📊 GitHub Stats

<p align="center">
  <img src="./profile/stats.svg" alt="GitHub stats" height="165" />
  <img src="./profile/top-langs.svg" alt="Top languages" height="165" />
</p>

---

### 🎯 What I'm Working Toward

- 🔭 Building production-ready full-stack and mobile applications
- 🧠 Deepening my knowledge of AI integration in everyday software
- 🌱 Learning system design, testing, and CI/CD best practices
- 🤝 Contributing to open-source and collaborative team projects

<p align="center"><sub>I'm always open to internships, collaborations, and conversations about tech — feel free to reach out.</sub></p>
